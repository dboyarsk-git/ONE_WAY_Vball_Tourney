ONE WAY Grass 4s — FINAL LIVE BUILD

WHAT CHANGED
- Admin code changed to: onewaygrass
- No admin hint is displayed on the website
- Team payment/check-in status is visible to everyone
- Only admin can edit team name, payment, or check-in
- Schedule is grouped into Pool A / B / C / D, matching the Teams page
- Live Supabase syncing remains enabled

UPLOAD
1. Replace the current GitHub index.html with this index.html.
2. Commit changes.
3. Wait for GitHub Pages deployment.
4. Hard refresh on computer and phone.

NOTE
supabase_setup.sql does not need to be run again if your earlier SQL setup already succeeded.
